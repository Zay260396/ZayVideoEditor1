package com.zay.videoeditor

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val bg = 0xFF100B1D.toInt()
    private val panel = 0xFF1B1430.toInt()
    private val purple = 0xFF9B72F2.toInt()
    private val white = 0xFFF7F3FF.toInt()
    private val muted = 0xFFB8AACF.toInt()

    private var videoUri: Uri? = null
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var startMs = 0L
    private var endMs = 0L
    private var durationMs = 0L
    private var statusText: TextView? = null
    private var trimStart: SeekBar? = null
    private var trimEnd: SeekBar? = null
    private var exportButton: Button? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            loadVideo(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("ZAY VIDEO", 12f, purple, true))
        brand.addView(label("EDITOR", 25f, white, true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val version = label("STUDIO  •  1.0", 10f, muted, true)
        header.addView(version)
        page.addView(header)
        page.addView(space(18))

        val intro = label("Create something beautiful.", 20f, white, true)
        page.addView(intro)
        page.addView(label("Edit video dengan sederhana, langsung dari HP kamu.", 13f, muted, false))
        page.addView(space(18))

        val previewCard = card()
        previewCard.orientation = LinearLayout.VERTICAL
        previewCard.setPadding(dp(12), dp(12), dp(12), dp(12))
        val pv = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(0xFF080611.toInt())
        }
        playerView = pv
        previewCard.addView(pv, LinearLayout.LayoutParams(-1, dp(210)))
        previewCard.addView(space(10))
        previewCard.addView(label("VIDEO PREVIEW", 11f, purple, true))
        page.addView(previewCard)
        page.addView(space(16))

        val importButton = button("＋   Pilih video dari galeri", true) {
            pickVideo.launch(arrayOf("video/*"))
        }
        page.addView(importButton, LinearLayout.LayoutParams(-1, dp(52)))
        page.addView(space(18))

        page.addView(sectionTitle("TRIM VIDEO"))
        page.addView(space(8))
        val trimCard = card()
        trimCard.orientation = LinearLayout.VERTICAL
        trimCard.setPadding(dp(16), dp(14), dp(16), dp(14))
        trimCard.addView(label("Atur titik awal dan akhir klip", 14f, white, true))
        trimCard.addView(space(10))
        trimCard.addView(label("Mulai", 12f, muted, true))
        trimStart = SeekBar(this).apply { max = 100; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(purple); thumbTintList = android.content.res.ColorStateList.valueOf(purple) }
        trimCard.addView(trimStart)
        trimCard.addView(space(8))
        trimCard.addView(label("Selesai", 12f, muted, true))
        trimEnd = SeekBar(this).apply { max = 100; progress = 100; progressTintList = android.content.res.ColorStateList.valueOf(purple); thumbTintList = android.content.res.ColorStateList.valueOf(purple) }
        trimCard.addView(trimEnd)
        val hint = label("Pilih video terlebih dahulu untuk mengaktifkan pemotongan.", 11f, muted, false)
        trimCard.addView(space(6))
        trimCard.addView(hint)
        trimStart?.isEnabled = false
        trimEnd?.isEnabled = false
        trimStart?.setOnSeekBarChangeListener(trimListener(true))
        trimEnd?.setOnSeekBarChangeListener(trimListener(false))
        page.addView(trimCard)
        page.addView(space(18))

        page.addView(sectionTitle("EXPORT"))
        page.addView(space(8))
        exportButton = button("⇧   Export video", true) { exportVideo() }.apply { isEnabled = false; alpha = 0.55f }
        page.addView(exportButton, LinearLayout.LayoutParams(-1, dp(52)))
        page.addView(space(10))
        statusText = label("Belum ada video yang dipilih.", 12f, muted, false)
        page.addView(statusText)
        page.addView(space(22))

        val tools = card()
        tools.orientation = LinearLayout.VERTICAL
        tools.setPadding(dp(16), dp(14), dp(16), dp(14))
        tools.addView(label("FITUR YANG TERSEDIA", 11f, purple, true))
        tools.addView(space(8))
        tools.addView(label("• Impor video dari galeri\n• Preview dan kontrol pemutaran\n• Potong bagian awal/akhir video\n• Ekspor hasil ke folder Movies/ZayVideoEditor", 13f, white, false))
        page.addView(tools)
        page.addView(space(20))
        val footer = label("ZayVideoEditor  •  Made for creators", 11f, muted, false)
        footer.gravity = Gravity.CENTER
        page.addView(footer)
    }

    private fun loadVideo(uri: Uri) {
        videoUri = uri
        player?.release()
        player = ExoPlayer.Builder(this).build().also {
            playerView?.player = it
            it.setMediaItem(MediaItem.fromUri(uri))
            it.prepare()
            it.playWhenReady = false
            it.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        durationMs = it.duration.coerceAtLeast(0)
                        endMs = durationMs
                        trimStart?.isEnabled = durationMs > 0
                        trimEnd?.isEnabled = durationMs > 0
                        exportButton?.isEnabled = true
                        exportButton?.alpha = 1f
                        statusText?.text = "Video siap • ${formatTime(durationMs)}"
                    }
                }
            })
        }
    }

    private fun trimListener(isStart: Boolean) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (!fromUser || durationMs <= 0) return
            val value = durationMs * progress / 100
            if (isStart) {
                startMs = value.coerceAtMost((endMs - 500).coerceAtLeast(0))
            } else {
                endMs = value.coerceAtLeast(startMs + 500).coerceAtMost(durationMs)
            }
            statusText?.text = "Potongan: ${formatTime(startMs)} – ${formatTime(endMs)}"
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun exportVideo() {
        val uri = videoUri ?: return
        if (durationMs <= 0L) {
            statusText?.text = "Durasi video belum terbaca. Coba pilih video lagi."
            return
        }
        val start = startMs.coerceIn(0, durationMs - 1)
        val end = endMs.coerceIn(start + 1, durationMs)
        if (end - start < 500) {
            statusText?.text = "Pilih durasi potongan minimal 0,5 detik."
            return
        }
        exportButton?.isEnabled = false
        statusText?.text = "Sedang menyiapkan export… jangan tutup aplikasi."
        val outputDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val output = File(outputDir, "ZayVideo_${System.currentTimeMillis()}.mp4")
        val item = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(start)
                    .setEndPositionMs(end)
                    .build()
            ).build()
        val edited = EditedMediaItem.Builder(item).build()
        val transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    exportButton?.isEnabled = true
                    statusText?.text = "Export selesai! File: ${output.name}\nLokasi: Android/data/com.zay.videoeditor/files/Movies"
                    Toast.makeText(this@MainActivity, "Video berhasil diekspor", Toast.LENGTH_LONG).show()
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    exportButton?.isEnabled = true
                    statusText?.text = "Export gagal: ${exportException.message ?: "format video tidak didukung"}"
                }
            }).build()
        try {
            transformer.start(edited, output.absolutePath)
        } catch (e: Exception) {
            exportButton?.isEnabled = true
            statusText?.text = "Tidak bisa memulai export: ${e.message}"
        }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(panel)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel); cornerRadius = dp(18).toFloat()
        }
    }

    private fun sectionTitle(text: String) = label(text, 12f, purple, true)

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setLineSpacing(dp(3).toFloat(), 1f)
        }

    private fun button(text: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        setTextColor(if (primary) 0xFFFFFFFF.toInt() else white)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(if (primary) 0xFF7545D8.toInt() else panel)
            cornerRadius = dp(14).toFloat()
        }
        setOnClickListener { action() }
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatTime(ms: Long): String {
        val seconds = ms / 1000
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    override fun onDestroy() {
        playerView?.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
